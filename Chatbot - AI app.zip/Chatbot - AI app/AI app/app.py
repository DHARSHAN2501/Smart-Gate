"""
Smart Gate AI Chatbot — Flask Backend
=====================================
Run: python app.py
URL: http://localhost:5000
"""

from flask import Flask, render_template, request, jsonify
import re

app = Flask(__name__)

# ─────────────────────────────────────────────────────────────
#  KNOWLEDGE BASE  (keyword list, answer)
#  answer can contain:
#    **bold**  → <strong>
#    TABLE:    → rendered as HTML table
#    - item    → list item
# ─────────────────────────────────────────────────────────────
KNOWLEDGE = [

    (["hello","hi","வணக்கம்","hai","hey","namaste","start"],
     """வணக்கம்! 🙏 நான் **Smart Gate AI Assistant**!

உங்கள் project பத்தி எந்த கேள்வியும் கேளுங்க.
Tamil / English — எந்த மொழியும் ok! 🚗✨"""),

    (["project","என்ன செய்","about","overview","smart gate","பத்தி","describe","what is"],
     """**Smart Gate: AI-Based Vehicle Identification System** 🚗

❌ **Problem (பழைய method):**
- Security guard manually check → slow, errors
- RFID cards lost/stolen
- CCTV only records — no analytics

✅ **Our Solution:**
- 📷 Camera → Vehicle capture
- 🎯 YOLOv8 → Detect (Car/Bike/Truck)
- 📖 EasyOCR → Plate number read
- 🗄️ MySQL → Entry/Exit log
- 🌐 Flask → Web dashboard + Reports

TABLE:
College|Ramakrishna Mission Polytechnic College, Chennai
Degree|Diploma in Computer Engineering
Year|April 2026
Guide|D. Dhilipkumaar M.E. (HOD)
External|Mr. T.S. Jayaraman"""),

    (["team","member","யார்","பண்ணாங்க","student","who","name","reg"],
     """👥 **Project Team Members**

TABLE:
Name|Register Number|Role
Dharshan S|24509620|Team Lead
Gokulnath V|24509623|Developer
Sanjay V|24509649|Developer
Saravanan A J|24592267|Developer

**Guide:** D. Dhilipkumaar, M.E. (HOD, Dept. of Computer Engineering)
**External Guide:** Mr. T.S. Jayaraman"""),

    (["technology","tech","tool","library","framework","use பண்","எந்த","language","technologies"],
     """🔧 **Technologies Used**

TABLE:
No.|Technology|Purpose|Type
1|Python 3.10|Main programming language|Language
2|OpenCV|Camera & image processing|Library
3|YOLOv8|Real-time vehicle detection|AI Model
4|EasyOCR|License plate text reading|OCR Engine
5|Flask|Web dashboard & reports|Framework
6|MySQL (XAMPP)|Database storage|Database
7|HTML/CSS/JS|Frontend interface|Web Tech"""),

    (["எப்படி","how","work","step","process","flow","explain","working","வேலை"],
     """⚙️ **System Working — Step by Step**

TABLE:
Step|Process|Technology Used
1|Vehicle enters camera view|OpenCV
2|Video frame capture + preprocessing|OpenCV
3|Vehicle detected & classified|YOLOv8
4|License plate region isolated|YOLOv8
5|Plate characters read → TN10AB1234|EasyOCR
6|Check against authorized database|MySQL
7|✅ Match → Gate Open / ❌ No match → Denied|Flask + MySQL
8|Entry/Exit time auto-logged|MySQL
9|Result shown on dashboard|Flask

⚡ **Total processing time: ~2-3 seconds per vehicle!**"""),

    (["yolo","object detect","detection model","you only"],
     """🎯 **YOLOv8 — You Only Look Once**

Ultralytics company develop பண்ணது!
Real-time AI object detection model.

TABLE:
Feature|Details
Full Form|You Only Look Once
Developer|Ultralytics
Version Used|YOLOv8
Input|Camera video frame
Output|Vehicle type + bounding box
Vehicle Types|Car / Bike / Truck
Speed|Real-time (~30 FPS)
Cost|Free & Open-source

Smart Gate-இன் **core AI brain** — இல்லன்னா detection இல்ல!"""),

    (["ocr","easyocr","plate","read","character","license","number plate"],
     """📖 **EasyOCR — Optical Character Recognition**

Image → Digital Text conversion!

TABLE:
Stage|Process|Example
Input|Cropped plate image|[Image of plate]
Detection|Characters located|TN, 10, AB, 1234
Recognition|Text extracted|TN10AB1234
Output|Digital text string|"TN10AB1234"

**Features:**
- ✅ Tilted / dirty plates support
- ✅ Multiple languages
- ✅ High accuracy in good lighting
- ✅ Free & Open-source"""),

    (["module","component","part","division","section"],
     """📦 **5 System Modules**

TABLE:
Module|Name|Technology|Function
01|Vehicle Detection & Capture|Camera + OpenCV|Live video, preprocessing
02|Number Plate Recognition|EasyOCR|Plate text extraction
03|Vehicle Model Identification|YOLOv8|Car / Bike / Truck classify
04|Database & Logging|MySQL|plate, type, time, status
05|Web Interface & Reports|Flask|Logs, search, PDF/Excel/CSV"""),

    (["hardware","processor","ram","camera","specification","computer","config"],
     """💻 **Hardware Requirements**

TABLE:
No.|Component|Specification|Purpose
1|Processor|Intel i5 3.1 GHz+|Core Processing
2|RAM|8 GB|Multitasking
3|Storage|250 GB SSD/HDD|Data Storage
4|Camera|HD Webcam / CCTV|Image Capture
5|Display|24 inch LED Monitor|Admin Dashboard

✅ Standard office computer போதும் — Expensive hardware தேவையில்ல!"""),

    (["software","python","flask","mysql","install","requirement","ide","tool"],
     """🖥️ **Software Requirements**

TABLE:
No.|Category|Technology|Version
1|Language|Python|3.10+
2|Computer Vision|OpenCV (cv2)|4.x
3|AI / ML Model|YOLOv8 (Ultralytics)|Latest
4|OCR Engine|EasyOCR|Latest
5|Web Backend|Flask|2.x
6|Database|MySQL via XAMPP|8.x
7|IDE|Spyder (Anaconda)|Latest

**📦 Install commands:**
pip install ultralytics easyocr flask opencv-python mysql-connector-python"""),

    (["database","mysql","table","store","log","entry","exit","sql","db","schema"],
     """🗄️ **MySQL Database Design**

**Table 1: vehicle** (Vehicle master data)

TABLE:
Column|Data Type|Key|Description
plate_number|VARCHAR(20)|PRIMARY KEY|Vehicle registration
model|VARCHAR(50)||Vehicle model name
owner_name|VARCHAR(100)||Owner full name
vehicle_type|VARCHAR(20)||Car / Bike / Truck
vehicle_color|VARCHAR(30)||Vehicle color

**Table 2: home_vehicle** (Authorized vehicles)

TABLE:
Column|Data Type|Key|Description
plate_number|VARCHAR(20)|PRIMARY KEY|Authorized plate
vehicle_type|VARCHAR(20)||Vehicle type

**Table 3: vehicle_activity** (Entry/Exit logs)

TABLE:
Column|Data Type|Key|Description
log_id|INT|PRIMARY KEY (Auto)|Unique log ID
plate_number|VARCHAR(20)|FOREIGN KEY|Vehicle reference
entry_time|DATETIME||Entry timestamp
exit_time|DATETIME||Exit timestamp
status|ENUM||INSIDE / COMPLETED"""),

    (["flask","dashboard","web","interface","browser","report","admin","portal"],
     """🌐 **Flask Web Dashboard Features**

TABLE:
Feature|Description
Real-time Logs|Live vehicle entry/exit monitoring
Vehicle Search|Search by plate number instantly
Date Filter|View records by specific date
Daily Count|Vehicle count chart by day
PDF Report|One-click PDF export
Excel Report|.xlsx format export
CSV Export|CSV format for analysis
Admin Login|Secure authentication
Role Access|Admin / Security staff roles

**URL:** http://localhost:5000
**Browser:** Chrome, Firefox, Edge — any browser!"""),

    (["test","result","pass","fail","accuracy","testing","verify"],
     """✅ **Testing Results — All 6 Test Cases PASSED!**

TABLE:
No.|Test Scenario|Expected Result|Actual Result|Status
1|Vehicle enters camera|Vehicle detected|Detected correctly|✅ PASS
2|Clear number plate image|Plate extracted|Extracted accurately|✅ PASS
3|Data logging check|Stored with timestamp|Stored correctly|✅ PASS
4|Report generation|PDF/Excel/CSV created|Generated successfully|✅ PASS
5|Email alert|Log sent to email|Email sent|✅ PASS
6|Web interface check|Dashboard works|Working correctly|✅ PASS

**Testing Methods:**
- Unit Testing — Each module separately
- Integration Testing — All modules together
- Performance Testing — Different lighting conditions"""),

    (["future","enhancement","plan","next","upgrade","improvement","scope"],
     """🚀 **Future Enhancements**

TABLE:
No.|Enhancement|Description|Priority
1|Cloud Integration|Multi-gate remote monitoring|High
2|Mobile App|iOS & Android real-time alerts|High
3|Enhanced OCR|Rain/fog/night conditions|Medium
4|Multi-Camera|Multiple gates simultaneously|Medium
5|Auto Gate Barrier|Hardware motor integration|High
6|Push Notifications|SMS / WhatsApp / Email|Medium
7|Face Recognition|Driver identity verification|Low
8|AI Analytics|Traffic pattern analysis|Low"""),

    (["advantage","benefit","feature","why","special","offline","good"],
     """💡 **Smart Gate Key Advantages**

TABLE:
Advantage|Description
🔌 Offline Capability|Internet இல்லாமலும் run ஆகும்
💰 Cost-Effective|All open-source tools — zero license cost
⚡ Real-Time Speed|2-3 seconds per vehicle processing
📊 Auto Reports|PDF/Excel one-click generation
🔒 High Security|Admin login + tamper-proof digital logs
📈 Scalable|Add cameras, upgrade to cloud anytime
🎯 High Accuracy|AI-powered — better than manual checking
🖥️ User-Friendly|Simple browser-based interface"""),

    (["problem","existing","issue","rfid","manual","guard","old","limitation"],
     """❌ **Existing System Limitations**

TABLE:
System|Problem|Impact
RFID Cards|Lost / stolen / duplicated|Security risk
Passwords|Shared / misused|Unauthorized access
Manual Guard|Human errors, slow|Traffic delays
Traditional CCTV|No automatic analytics|Manual review needed
Manual Logs|Handwritten — inaccurate|Data loss risk

**Missing Features in Old Systems:**
- ❌ No automatic plate reading
- ❌ No digital entry/exit logs
- ❌ No real-time monitoring
- ❌ No automated reports
- ❌ No unauthorized vehicle alerts

✅ **இதனால Smart Gate develop பண்ணோம்!**"""),

    (["conclusion","summary","final","சுருக்கம்","overall","result"],
     """🎯 **Project Conclusion**

TABLE:
Achievement|Details
Automation|Human verification effort eliminated
Accuracy|AI-powered — minimal errors
Speed|2-3 seconds per vehicle
Security|Tamper-proof digital logs
Cost|Open-source — affordable
Reliability|All 6 test cases passed
Offline|Works without internet

**Suitable Environments:**
- 🏫 Schools & Colleges
- 🏢 Corporate Offices
- 🏘️ Residential Communities
- 🏭 Industrial Areas
- 🅿️ Parking Facilities

**Smart Gate proves: AI automation > Traditional manual security!** 🚀"""),
]


def get_answer(question: str) -> dict:
    """Match question → best answer, return as dict with type info"""
    q = question.lower().strip()
    best_ans = None
    best_score = 0

    for keywords, answer in KNOWLEDGE:
        score = sum(len(kw) for kw in keywords if kw.lower() in q)
        if score > best_score:
            best_score = score
            best_ans = answer

    if not best_ans or best_score == 0:
        best_ans = """🤔 இந்த topics பத்தி கேளுங்க:

TABLE:
Topic|Keywords to ask
📋 Project Overview|project, about, what is
👥 Team Members|team, members, who, name
🔧 Technologies|tech, tools, python, yolo, ocr
⚙️ How it Works|how, work, steps, process
💻 Hardware|hardware, processor, RAM
🖥️ Software|software, install, requirements
🗄️ Database|database, mysql, tables
✅ Testing|test, results, accuracy
🚀 Future Plans|future, enhancement, plan
💡 Advantages|advantage, benefit, offline"""

    return format_answer(best_ans)


def format_answer(text: str) -> dict:
    """Convert raw answer text → HTML with tables, bold, lists"""
    lines = text.strip().split('\n')
    html_parts = []
    i = 0

    while i < len(lines):
        line = lines[i].strip()

        # TABLE: keyword — collect table rows
        if line == 'TABLE:':
            i += 1
            rows = []
            while i < len(lines) and lines[i].strip() and lines[i].strip() != 'TABLE:':
                rows.append(lines[i].strip())
                i += 1

            if rows:
                # First row = header if it has 2+ cols
                header_cols = rows[0].split('|')
                is_header_row = len(header_cols) >= 2

                html = '<div class="sg-table-wrap"><table class="sg-table">'
                if is_header_row:
                    html += '<thead><tr>'
                    for col in header_cols:
                        html += f'<th>{col.strip()}</th>'
                    html += '</tr></thead><tbody>'
                    data_rows = rows[1:]
                else:
                    html += '<tbody>'
                    data_rows = rows

                for row in data_rows:
                    cols = row.split('|')
                    html += '<tr>'
                    for col in cols:
                        html += f'<td>{col.strip()}</td>'
                    html += '</tr>'

                html += '</tbody></table></div>'
                html_parts.append(html)
            continue

        # Empty line → paragraph break
        if not line:
            html_parts.append('<br>')
            i += 1
            continue

        # List item
        if line.startswith('- '):
            content = line[2:]
            content = apply_inline(content)
            html_parts.append(f'<div class="sg-list-item">• {content}</div>')
            i += 1
            continue

        # Regular text line
        line = apply_inline(line)
        html_parts.append(f'<div class="sg-line">{line}</div>')
        i += 1

    return {'html': '\n'.join(html_parts)}


def apply_inline(text: str) -> str:
    """Apply inline formatting: **bold**, emojis stay as-is"""
    text = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', text)
    return text


# ── Routes ────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    question = data.get('message', '').strip()
    if not question:
        return jsonify({'html': 'கேள்வி type பண்ணுங்க! 😊'})
    result = get_answer(question)
    return jsonify(result)


if __name__ == '__main__':
    print("=" * 55)
    print("  🚗 Smart Gate AI Chatbot — Flask Server")
    print("=" * 55)
    print("  URL  : http://localhost:5000")
    print("  Mode : Offline (No API key needed)")
    print("  Stop : Ctrl+C")
    print("=" * 55)
    app.run(debug=True, port=5000)
