import re
import os
import io
import json
import math
import time
import hashlib
from collections import Counter

KB_DIR = os.path.join(os.path.dirname(__file__), "data")
KB_PATH = os.path.join(KB_DIR, "chatbot_kb.json")
MAX_CHUNK_CHARS = 900
MAX_CHUNKS_PER_DOC = 160
MIN_KB_SCORE = 1.2

_STOPWORDS = {
    "the", "and", "a", "an", "of", "to", "in", "for", "on", "with", "by", "is", "are", "was",
    "were", "be", "as", "at", "from", "that", "this", "it", "or", "not", "your", "our", "their",
    "we", "you", "they", "i", "me", "my", "mine", "us", "about", "into", "can", "could", "should",
    "will", "would", "may", "might", "also", "than", "then", "there", "here", "over", "under",
}


def _ensure_kb_store():
    os.makedirs(KB_DIR, exist_ok=True)
    if not os.path.exists(KB_PATH):
        with open(KB_PATH, "w", encoding="utf-8") as f:
            json.dump({"updated_at": None, "docs": [], "chunks": []}, f)


def _load_kb():
    _ensure_kb_store()
    try:
        with open(KB_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if "docs" not in data:
            data["docs"] = []
        if "chunks" not in data:
            data["chunks"] = []
        return data
    except Exception:
        return {"updated_at": None, "docs": [], "chunks": []}


def _save_kb(data):
    _ensure_kb_store()
    with open(KB_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def kb_status():
    data = _load_kb()
    return {
        "docs": len(data.get("docs", [])),
        "chunks": len(data.get("chunks", [])),
        "updated_at": data.get("updated_at"),
    }


def _normalize_text(text):
    text = text.replace("\x00", " ").strip()
    text = re.sub(r"\s+", " ", text)
    return text


def _tokenize(text):
    tokens = re.findall(r"[\w']+", text.lower(), flags=re.UNICODE)
    return [t for t in tokens if len(t) > 1 and t not in _STOPWORDS]


def _chunk_text(text, max_chars=MAX_CHUNK_CHARS):
    text = _normalize_text(text)
    if not text:
        return []
    if len(text) <= max_chars:
        return [text]
    sentences = re.split(r"(?<=[.!?])\s+", text)
    chunks = []
    buf = ""
    for sentence in sentences:
        if not sentence:
            continue
        if len(buf) + len(sentence) + 1 <= max_chars:
            buf = (buf + " " + sentence).strip()
        else:
            if buf:
                chunks.append(buf)
            buf = sentence
    if buf:
        chunks.append(buf)
    return chunks


def _extract_text_from_upload(filename, data_bytes):
    ext = os.path.splitext(filename)[1].lower()
    if ext in {".txt", ".md"}:
        for enc in ("utf-8", "utf-16", "latin-1"):
            try:
                return data_bytes.decode(enc)
            except Exception:
                continue
        return None, "Could not decode the text file."

    if ext == ".pdf":
        try:
            import PyPDF2
        except Exception:
            return None, "PyPDF2 not installed. Please upload a .txt report or install PyPDF2."
        try:
            reader = PyPDF2.PdfReader(io.BytesIO(data_bytes))
            pages = [page.extract_text() or "" for page in reader.pages]
            return "\n".join(pages)
        except Exception:
            return None, "Failed to read the PDF file."

    if ext == ".docx":
        try:
            import docx
        except Exception:
            return None, "python-docx not installed. Please upload a .txt report or install python-docx."
        try:
            doc = docx.Document(io.BytesIO(data_bytes))
            paragraphs = [p.text for p in doc.paragraphs]
            return "\n".join(paragraphs)
        except Exception:
            return None, "Failed to read the DOCX file."

    return None, "Unsupported file type. Use .pdf, .txt, .md, or .docx."


def ingest_document(filename, data_bytes):
    if not filename:
        return {"ok": False, "error": "Missing file name."}
    if not data_bytes:
        return {"ok": False, "error": "Empty file."}

    extracted = _extract_text_from_upload(filename, data_bytes)
    if isinstance(extracted, tuple):
        text, err = extracted
        if err:
            return {"ok": False, "error": err}
    else:
        text = extracted

    text = _normalize_text(text or "")
    if len(text) < 120:
        return {"ok": False, "error": "Report text is too short to learn from."}

    doc_hash = hashlib.sha1(text.encode("utf-8", errors="ignore")).hexdigest()
    kb = _load_kb()
    if any(doc.get("hash") == doc_hash for doc in kb.get("docs", [])):
        return {"ok": False, "error": "This report was already learned."}

    chunks = _chunk_text(text)
    if len(chunks) > MAX_CHUNKS_PER_DOC:
        chunks = chunks[:MAX_CHUNKS_PER_DOC]

    doc_id = f"doc-{int(time.time() * 1000)}"
    created_at = time.strftime("%Y-%m-%d %H:%M:%S")
    doc_meta = {
        "id": doc_id,
        "name": filename,
        "hash": doc_hash,
        "chunks": len(chunks),
        "created_at": created_at,
    }
    kb.setdefault("docs", []).append(doc_meta)
    for idx, chunk in enumerate(chunks, start=1):
        kb.setdefault("chunks", []).append(
            {
                "id": f"{doc_id}-{idx}",
                "doc_id": doc_id,
                "source": filename,
                "text": chunk,
            }
        )

    kb["updated_at"] = created_at
    _save_kb(kb)
    return {"ok": True, "doc": doc_meta, "chunks": len(chunks)}


def _best_snippet(text, query_tokens, max_len=240):
    if not text:
        return ""
    sentences = re.split(r"(?<=[.!?])\s+", text)
    best = ""
    best_score = 0

    for sentence in sentences:
        tokens = set(_tokenize(sentence))
        score = len(tokens & query_tokens)
        if score > best_score:
            best_score = score
            best = sentence
    if not best:
        best = text
    best = best.strip()
    if len(best) > max_len:
        cut = best[:max_len].rsplit(" ", 1)[0]
        best = (cut or best[:max_len]).strip() + "..."
    return best


def search_kb(question, top_k=3):
    data = _load_kb()
    chunks = data.get("chunks", [])
    if not chunks:
        return []

    q_tokens = set(_tokenize(question))
    if not q_tokens:
        return []

    token_sets = []
    df = Counter()
    for chunk in chunks:
        tokens = set(_tokenize(chunk.get("text", "")))
        token_sets.append(tokens)
        for token in tokens:
            df[token] += 1

    n_chunks = len(chunks)
    results = []
    for idx, chunk in enumerate(chunks):
        tokens = token_sets[idx]
        if not tokens:
            continue
        match = q_tokens & tokens
        if not match:
            continue
        score = 0.0
        for token in match:
            score += math.log((n_chunks + 1) / (df[token] + 1)) + 1.0
        coverage = len(match) / max(len(q_tokens), 1)
        score *= (0.7 + 0.3 * coverage)
        results.append(
            {
                "score": score,
                "snippet": _best_snippet(chunk.get("text", ""), q_tokens),
                "source": chunk.get("source", "report"),
            }
        )

    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:top_k]

# ─────────────────────────────────────────────────────────────
#  KNOWLEDGE BASE  (keyword list, answer)
#  answer can contain:
#    **bold**  → <strong>
#    TABLE:    → rendered as HTML table
#    - item    → list item
# ─────────────────────────────────────────────────────────────
KNOWLEDGE = [
    (["hello", "hi", "வணக்கம்", "hai", "hey", "namaste", "start"],
     """வணக்கம்! 🙏 நான் **Smart Gate AI Assistant**!
உங்கள் project-இன் **Mini-AI**-யாக நான் செயல்படுவேன்.
Project details, Tech Stack, Workflow — எது வேணும்னாலும் கேளுங்க!"""),

    (["what is smart gate", "project explanation", "describe project", "about", "overview", "என்ன", "பத்தி", "explain project", "tell me about smart gate", "summary", "project name", "purpose of smart gate", "main objective"],
     """**Smart Gate: AI-Based Vehicle Identification System** 🚗

Smart Gate is an AI-powered vehicle monitoring system that automatically detects vehicles, reads their number plates, and records entry and exit information.

The purpose of Smart Gate is to automate gate security and vehicle logging using advanced computer vision.

**Main Functions:**
- Detect vehicles using AI (YOLOv8)
- Recognize number plates automatically (EasyOCR)
- Store vehicle information in a database (MySQL)
- Track entry and exit time
- Provide live monitoring dashboard (Flask)
- Generate analytics reports"""),

    (["problem", "solve", "why", "need", "reason", "smart gate solve", "advantage", "importance", "why important"],
     """Smart Gate automates vehicle monitoring and improves security by replacing manual gate entry logs with AI-based vehicle detection. 

**Key Benefits:**
- **Automation**: No manual entry required.
- **Security**: Accurate logging of all vehicles.
- **Analytics**: Data-driven insights on traffic flow.
- **Improved Security**: Prevents unauthorized access and maintains clear digital records.
- **Efficiency**: Reduces human error in logging plate numbers."""),

    (["who developed", "developer", "who made", "who created", "maker"],
     """The **Smart Gate System** was developed as a specialized AI project for automatic vehicle monitoring and gate control automation."""),

    (["where can it be used", "industries", "usage", "application", "place", "where to use", "target audience"],
     """Smart Gate can be used in various locations where vehicle tracking is required:
- **Residential Apartments** 🏢
- **Corporate Offices** 💼
- **Shopping Malls** 🛍️
- **Hospitals** 🏥
- **Industrial Zones** 🏭
- **Educational Institutions** 🎓"""),

    (["manual", "difference", "manual vs smart gate", "manual gate system", "traditional system"],
     """Unlike manual gate systems that require security guards to write down vehicle numbers on a notebook, **Smart Gate** is fully automated. It uses AI to "see" and "read" plates instantly, reducing wait times and improving data accuracy."""),

    (["internet", "offline", "cloud", "remote", "does it require internet", "work offline"],
     """🌐 **Offline Capability**
Smart Gate is designed to work **fully offline**. 
- It does **not** require an active internet connection for detection, OCR, or database logging.
- All data is stored on the local server (MySQL)."""),

    (["components", "hardware", "processor", "ram", "camera", "specification", "config", "what is required"],
     """💻 **Required Components**
- **Camera**: 1080p HD Webcam or IP Camera.
- **Server/PC**: Intel i5 or better recommended.
- **RAM**: 8GB+ for better AI performance.
- **Database**: MySQL (Local Server).
- **Communication**: SMTP for email alerts (Optional)."""),

    (["security", "secure", "how secure", "data protection"],
     """Smart Gate enhances security by providing a digital, tamper-proof audit trail of every vehicle entry/exit with photo evidence. Access to the dashboard and logs is protected by a secure login system."""),

    (["technology", "tech", "stack", "tool", "library", "framework", "technologies", "what technologies", "programming language", "ai model", "ocr"],
     """🔧 **Technology Stack**

TABLE:
Component|Technology
Programming|Python 3.x
AI Detection|YOLOv8 (Ultralytics)
AI OCR|EasyOCR (Deep Learning)
Computer Vision|OpenCV
Web Backend|Flask
Database|MySQL (Local)
Frontend|HTML5, CSS3, JS"""),

    (["how it works", "working", "process", "flow", "step", "எப்படி", "workflow", "explain how it works", "system architecture"],
     """⚙️ **System Architecture & Workflow**

The system follows a streamlined process to identify and log vehicles:

TABLE:
Step|Process|Technology
Step 1|Video Capture|Camera captures live video via **OpenCV**.
Step 2|Vehicle Detection|**YOLOv8** model detects the vehicle and type.
Step 3|Plate Extraction|The number plate area is isolated from the frame.
Step 4|OCR Recognition|**EasyOCR** reads the alphanumeric characters.
Step 5|Database Log|Data (Plate, Time, Image) is saved in **MySQL**.
Step 6|Dashboard|Admins view real-time logs and analytics."""),

    (["vehicle detection", "detect", "yolo", "how does it detect", "identify vehicles"],
     """🎯 **Vehicle Detection (YOLOv8)**
The system uses the **YOLOv8** (You Only Look Once) deep learning model for real-time detection. 

**Capabilities:**
- Detects Cars, Bikes, Buses, and Trucks.
- Handles multiple vehicles in a single frame.
- High speed and accuracy in various lighting conditions."""),

    (["ocr", "easyocr", "number plate recognition", "read plate", "reading characters", "plate detection"],
     """📖 **Number Plate Recognition (OCR)**
Once a plate is detected, **EasyOCR** is used to extract the text.

**Features:**
- Supports Indian license plate formats.
- Converts the plate image into a digital string.
- Integrated with the database for instant verification."""),

    (["database", "mysql", "store", "data", "information", "where is data stored", "tables", "db info"],
     """🗄️ **Data Storage (MySQL)**
All vehicle activities are stored in a **MySQL** database for permanent record keeping.

**What we store:**
- Plate Number
- Vehicle Category & Type
- Entry & Exit Timestamps
- Captured Vehicle Image Path"""),

    (["dashboard", "web", "interface", "features", "dashboard help", "ui"],
     """🌐 **Admin Dashboard**
The Flask-based dashboard provides a user-friendly interface for security monitoring.

**Key Features:**
- **Live Monitoring**: View processing in real-time.
- **Logs**: Search and filter vehicle history.
- **Analytics**: Visual reports on traffic trends.
- **Settings**: Configure system and email alerts."""),

    (["logs", "vehicle logs", "search", "show logs", "view logs"],
     """📋 **Vehicle Activity Logs**
Vehicle logs store every entry and exit. You can search by **Plate Number** or **Date** to find specific records. The logs help in tracking unauthorised entries and monitoring stay duration."""),

    (["analytics", "report", "stats", "statistics", "report analytics"],
     """📊 **Analytics & Insights**
The system automatically generates traffic statistics:
- **Total Entries**: Daily/Monthly counts.
- **Peak Hours**: Identifying the busiest times of day.
- **Vehicle Split**: Ratio of Cars vs Bikes vs Trucks."""),

    (["troubleshooting", "error", "camera not detected", "plate not detected", "not loading", "system troubleshooting", "fix", "issue"],
     """🛠️ **Troubleshooting Guide**

- **Camera Error?** Ensure the camera is connected and the OpenCV index (usually 0) is correct.
- **OCR Failed?** Check if the plate is clean and well-lit.
- **Server Down?** Restart the Flask application (`app.py`)."""),

    (["future", "scope", "improvement", "next", "future scope"],
     """🚀 **Future Improvements**
We plan to expand the system with:
- **Mobile App**: Real-time alerts on your phone.
- **Cloud integration**: Database access from anywhere.
- **Gate Control**: Automatic barrier opening for authorized vehicles.
- **Facial Recognition**: Identifying drivers as well."""),

    (["viva", "defense", "why yolo", "why easyocr", "challenges", "accuracy improvement", "limitations"],
     """🎓 **Project Viva & Defense Guide**

**Q: Why YOLOv8?**
A: YOLOv8 is chosen for its state-of-the-art speed/accuracy trade-off. It provides real-time detection (~1ms - 10ms per frame) which is essential for gate automation.

**Q: Why EasyOCR?**
A: EasyOCR is flexible, supports multiple languages, and works well without needing heavy GPU resources, making it ideal for standard computer systems.

**Q: Major Challenges?**
A: Handling low-light conditions, reading damaged or dusty plates, and optimizing the database for simultaneous read/write during high traffic.

**Q: Accuracy Improvement?**
A: By using sharper IR cameras, training a custom YOLO model on local plate formats, and applying image preprocessing (grayscale, noise reduction) before OCR.

**Q: System Limitations?**
A: Current accuracy depends on camera angle and lighting. Extreme rain or fog can degrade detection performance."""),

    (["hardware", "processor", "ram", "camera", "specification", "config"],
     """💻 **Hardware Requirements**
- **Processor**: Intel i5 3rd Gen or better.
- **RAM**: 8GB recommended for smooth AI operation.
- **Camera**: 1080p HD Webcam or IP Camera for clear plate images.
- **Storage**: SSD preferred for fast logging and database access."""),

    (["internet", "offline", "cloud", "remote"],
     """🌐 **Internet & Connectivity**
- **Standalone**: Smart Gate works fully **offline**. No internet is required for detection or logging.
- **Local Database**: MySQL runs on the local server.
- **Remote Access**: Cloud integration is possible in the future for multi-site monitoring."""),

    (["accuracy", "performance", "real-time", "fps", "speed"],
     """⚡ **System Performance**
- **Speed**: Detection to Log time: ~2-3 seconds.
- **Accuracy**: ~95% under good lighting conditions.
- **Real-time**: The camera feed is processed at 15-20 FPS (Frames Per Second) for fluid monitoring."""),
    (["admin", "manage", "authorized", "add vehicle", "settings info"],
     """🔐 **Admin & Settings Management**
- **Authorization**: Admins can add "Home Vehicles" via the **Settings** page. These plates are automatically categorized differently from visitor logs.
- **Security**: Access to settings and raw logs is restricted via the Glassmorphism login portal."""),
]

# AI Auto-SQL Logic
def generate_sql(question):
    q = question.lower().strip()

    # Query: Today's entries
    if "today" in q or "entered today" in q:
        return "SELECT * FROM vehicle_activity WHERE DATE(entry_time) = CURDATE() ORDER BY entry_time DESC LIMIT 10;"

    # Query: Currently inside
    if "currently inside" in q or "who is inside" in q or "inside now" in q:
        return "SELECT * FROM vehicle_activity WHERE status = 'Inside' ORDER BY entry_time DESC LIMIT 10;"

    # Query: Specific vehicle
    if "find vehicle" in q or "vehicle" in q or "search plate" in q:
        # Extract vehicle number (looking for alphanumeric strings > 6 chars)
        words = q.split()
        for word in words:
            clean_word = "".join(ch for ch in word if ch.isalnum()).upper()
            if len(clean_word) >= 5: # Support shorter plates too
                return f"SELECT * FROM vehicle_activity WHERE plate_number = '{clean_word}' ORDER BY entry_time DESC LIMIT 5;"

    return None

_KB_STATUS_KEYWORDS = {
    "kb", "knowledge base", "memory", "report status", "trained", "training", "learned", "learned report"
}


def _is_kb_status_query(q):
    return any(k in q for k in _KB_STATUS_KEYWORDS)


def get_answer(question: str) -> dict:
    """Match question → best answer, return as dict with type info"""
    q = question.lower().strip()
    best_ans = None
    best_score = 0

    if _is_kb_status_query(q):
        status = kb_status()
        updated = status.get("updated_at") or "Not yet"
        text = (
            "Knowledge Base Status\n\n"
            "TABLE:\n"
            "Metric|Value\n"
            f"Documents|{status.get('docs', 0)}\n"
            f"Chunks|{status.get('chunks', 0)}\n"
            f"Last Updated|{updated}"
        )
        return format_answer(text)

    kb_hits = search_kb(question)
    if kb_hits and kb_hits[0]["score"] >= MIN_KB_SCORE:
        text = "From your uploaded report, I found:\n"
        for hit in kb_hits:
            src = hit.get("source", "report")
            snippet = hit.get("snippet", "")
            if snippet:
                text += f"- {snippet} (Source: {src})\n"
        return format_answer(text)

    for keywords, answer in KNOWLEDGE:
        score = sum(1 for kw in keywords if kw.lower() in q)
        # More weight for exact matches
        if any(kw.lower() == q for kw in keywords):
            score += 10
        if score > best_score:
            best_score = score
            best_ans = answer

    if not best_ans or best_score == 0:
        best_ans = """🤔 இந்த topics பத்தி கேளுங்க:

TABLE:
Topic|Keywords to ask
📋 Project Overview|project, about, what is
🔧 Technologies|tech, tools, python, yolo, ocr
⚙️ How it Works|how, work, steps, process
🗄️ Database|database, mysql, tables
📋 Logs|logs, search, entries
🚀 Future Plans|future, enhancement, plan
🛠️ Troubleshooting|error, fix, camera"""

    return format_answer(best_ans)


def format_answer(text: str) -> dict:
    """Convert raw answer text → HTML with tables, bold, lists"""
    lines = text.strip().split('\n')
    html_parts = []
    i = 0

    while i < len(lines):
        line = lines[i].strip()

        # TABLE: keyword — collect table rows
        if line == 'TABLE:':
            i += 1
            rows = []
            while i < len(lines) and lines[i].strip() and lines[i].strip() != 'TABLE:':
                rows.append(lines[i].strip())
                i += 1

            if rows:
                # First row = header if it has 2+ cols
                header_cols = rows[0].split('|')
                is_header_row = len(header_cols) >= 2

                html = '<div class="sg-table-wrap"><table class="sg-table">'
                if is_header_row:
                    html += '<thead><tr>'
                    for col in header_cols:
                        html += f'<th>{col.strip()}</th>'
                    html += '</tr></thead><tbody>'
                    data_rows = rows[1:]
                else:
                    html += '<tbody>'
                    data_rows = rows

                for row in data_rows:
                    cols = row.split('|')
                    html += '<tr>'
                    for col in cols:
                        html += f'<td>{col.strip()}</td>'
                    html += '</tr>'

                html += '</tbody></table></div>'
                html_parts.append(html)
            continue

        # Empty line → paragraph break
        if not line:
            html_parts.append('<br>')
            i += 1
            continue

        # List item
        if line.startswith('- '):
            content = line[2:]
            content = apply_inline(content)
            html_parts.append(f'<div class="sg-list-item">• {content}</div>')
            i += 1
            continue

        # Regular text line
        line = apply_inline(line)
        html_parts.append(f'<div class="sg-line">{line}</div>')
        i += 1

    return {'html': '\n'.join(html_parts)}


def apply_inline(text: str) -> str:
    """Apply inline formatting: **bold**, emojis stay as-is"""
    text = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', text)
    return text
