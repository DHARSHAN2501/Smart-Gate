(function () {
  'use strict';

  /* ══════════════════════════════════════════
     DRAG — FAB button
  ══════════════════════════════════════════ */
  function makeDraggable(el, onClick) {
    let sx, sy, sleft, stop, moved;
    function pos(e) { return e.touches ? { x: e.touches[0].clientX, y: e.touches[0].clientY } : { x: e.clientX, y: e.clientY }; }
    function down(e) {
      var p = pos(e); sx = p.x; sy = p.y;
      var r = el.getBoundingClientRect(); sleft = r.left; stop = r.top; moved = false;
      el.classList.add('dragging');
      document.addEventListener('mousemove', move);
      document.addEventListener('touchmove', move, { passive: false });
      document.addEventListener('mouseup', up);
      document.addEventListener('touchend', up);
      e.preventDefault();
    }
    function move(e) {
      var p = pos(e), dx = p.x - sx, dy = p.y - sy;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) moved = true;
      if (!moved) return;
      var W = window.innerWidth, H = window.innerHeight, w = el.offsetWidth, h = el.offsetHeight;
      var nx = Math.max(0, Math.min(sleft + dx, W - w));
      var ny = Math.max(0, Math.min(stop + dy, H - h));
      el.style.left = nx + 'px'; el.style.top = ny + 'px'; el.style.right = 'auto'; el.style.bottom = 'auto';
      e.preventDefault();
    }
    function up() {
      el.classList.remove('dragging');
      document.removeEventListener('mousemove', move);
      document.removeEventListener('touchmove', move);
      document.removeEventListener('mouseup', up);
      document.removeEventListener('touchend', up);
      if (!moved && onClick) onClick();
    }
    el.addEventListener('mousedown', down);
    el.addEventListener('touchstart', down, { passive: false });
  }

  /* ══════════════════════════════════════════
     DRAG — Chat Panel via header
  ══════════════════════════════════════════ */
  function makePanelDraggable(panel, handle) {
    var sx, sy, sl, st;
    function pos(e) { return e.touches ? { x: e.touches[0].clientX, y: e.touches[0].clientY } : { x: e.clientX, y: e.clientY }; }
    function down(e) {
      if (e.target.id === 'sg-close') return;
      var p = pos(e); sx = p.x; sy = p.y;
      var r = panel.getBoundingClientRect(); sl = r.left; st = r.top;
      document.addEventListener('mousemove', move);
      document.addEventListener('touchmove', move, { passive: false });
      document.addEventListener('mouseup', up);
      document.addEventListener('touchend', up);
      e.preventDefault();
    }
    function move(e) {
      var p = pos(e), dx = p.x - sx, dy = p.y - sy;
      var W = window.innerWidth, H = window.innerHeight, w = panel.offsetWidth, h = panel.offsetHeight;
      var nx = Math.max(0, Math.min(sl + dx, W - w));
      var ny = Math.max(0, Math.min(st + dy, H - h));
      panel.style.left = nx + 'px'; panel.style.top = ny + 'px'; panel.style.right = 'auto'; panel.style.bottom = 'auto';
      e.preventDefault();
    }
    function up() {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('touchmove', move);
      document.removeEventListener('mouseup', up);
      document.removeEventListener('touchend', up);
    }
    handle.addEventListener('mousedown', down);
    handle.addEventListener('touchstart', down, { passive: false });
  }

  /* ══════════════════════════════════════════
     CHAT UI
  ══════════════════════════════════════════ */
  var isOpen = false, isBusy = false;

  function positionPanelFromFab(fab, panel) {
    if (!fab || !panel) return;
    var pad = 12;
    var wasHidden = !panel.classList.contains('open');
    if (wasHidden) {
      panel.style.visibility = 'hidden';
      panel.classList.add('open');
    }

    var r = fab.getBoundingClientRect();
    var W = window.innerWidth, H = window.innerHeight;
    var pw = panel.offsetWidth || 400;
    var ph = panel.offsetHeight || 560;

    var left = r.right - pw;
    left = Math.max(pad, Math.min(left, W - pw - pad));

    var top = r.top - ph - 16;
    if (top < pad) top = r.bottom + 16;
    if (top + ph > H - pad) top = Math.max(pad, H - ph - pad);

    panel.style.left = left + 'px';
    panel.style.top = top + 'px';
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';

    if (wasHidden) {
      panel.classList.remove('open');
      panel.style.visibility = '';
    }
  }

  window.sgToggle = function () {
    var panel = document.getElementById('sg-panel');
    var fab = document.getElementById('sg-fab');
    isOpen = !isOpen;
    if (isOpen) {
      positionPanelFromFab(fab, panel);
      panel.classList.add('open');
      fab.textContent = '✕';
      if (!document.getElementById('sg-msgs').children.length) sgWelcome();
    } else {
      panel.classList.remove('open');
      fab.textContent = '🤖';
    }
  }

  function addMsg(sender) {
    var msgs = document.getElementById('sg-msgs');
    var row = document.createElement('div');
    row.className = 'sg-row ' + sender;
    var av = document.createElement('div');
    av.className = 'sg-av ' + (sender === 'user' ? 'usr' : 'bot');
    av.textContent = sender === 'user' ? '👤' : '🤖';
    var bub = document.createElement('div');
    bub.className = 'sg-bub';
    if (sender === 'user') { row.appendChild(bub); row.appendChild(av); }
    else { row.appendChild(av); row.appendChild(bub); }
    msgs.appendChild(row);
    msgs.scrollTop = 99999;
    return bub;
  }

  function addTyping() {
    var msgs = document.getElementById('sg-msgs');
    var row = document.createElement('div');
    row.className = 'sg-row bot'; row.id = 'sg-typ';
    var av = document.createElement('div');
    av.className = 'sg-av bot'; av.textContent = '🤖';
    var bub = document.createElement('div');
    bub.className = 'sg-bub';
    bub.innerHTML = '<div class="sg-typing"><span></span><span></span><span></span></div>';
    row.appendChild(av); row.appendChild(bub);
    msgs.appendChild(row); msgs.scrollTop = 99999;
  }

  function removeTyping() {
    var t = document.getElementById('sg-typ'); if (t) t.remove();
  }

  function parseJsonResponse(r) {
    var ct = (r.headers && r.headers.get('content-type')) || '';
    if (!ct.includes('application/json')) {
      return r.text().then(function () {
        var msg = (r.status === 401)
          ? 'Login required. Please login and try again.'
          : 'Server returned HTML. Please check the Flask server.';
        throw new Error(msg);
      });
    }
    return r.json().then(function (data) {
      if (!r.ok) {
        var errMsg = (data && (data.error || data.message || data.html)) || ('Request failed (' + r.status + ')');
        throw new Error(errMsg);
      }
      return data;
    });
  }

  /* Stream HTML content char-by-char for text nodes, instant for tables */
  function streamHTML(bub, html) {
    // Extract tables out — render them instantly, stream only text parts
    var parts = html.split(/(<div class="sg-table-wrap">[\s\S]*?<\/div>)/g);
    var order = [];

    parts.forEach(function (part) {
      if (part.startsWith('<div class="sg-table-wrap">')) {
        order.push({ type: 'table', html: part });
      } else if (part.trim()) {
        order.push({ type: 'text', html: part });
      }
    });

    var partIdx = 0;
    function renderNext() {
      if (partIdx >= order.length) {
        isBusy = false;
        document.getElementById('sg-send').disabled = false;
        return;
      }
      var part = order[partIdx++];
      if (part.type === 'table') {
        bub.innerHTML += part.html;
        document.getElementById('sg-msgs').scrollTop = 99999;
        setTimeout(renderNext, 60);
      } else {
        // stream text
        var raw = part.html;
        var i = 0;
        var current = bub.innerHTML;
        function step() {
          if (i <= raw.length) {
            bub.innerHTML = current + raw.slice(0, i) + (i < raw.length ? '<span class="sg-cur"></span>' : '');
            document.getElementById('sg-msgs').scrollTop = 99999;
            var spd = raw.length > 400 ? 6 : 12;
            i += (raw.length > 500 ? 5 : 2);
            setTimeout(step, spd);
          } else {
            bub.innerHTML = current + raw;
            renderNext();
          }
        }
        step();
      }
    }
    renderNext();
  }

  function sgWelcome() {
    isBusy = true;
    document.getElementById('sg-send').disabled = true;
    addTyping();

    fetch('/chat_init')
      .then(r => r.json())
      .then(data => {
        removeTyping();
        var bub = addMsg('bot');
        streamHTML(bub, data.html || 'வணக்கம்! நான் எப்டி உதவி பண்ணட்டும்?');
      })
      .catch(err => {
        removeTyping();
        var bub = addMsg('bot');
        bub.textContent = 'வணக்கம்! I am ready to help you with the Smart Gate project.';
        isBusy = false;
        document.getElementById('sg-send').disabled = false;
      });
  }

  window.sgSend = function () {
    if (isBusy) return;
    var inp = document.getElementById('sg-inp');
    var q = inp.value.trim(); if (!q) return;
    inp.value = ''; inp.style.height = 'auto';
    isBusy = true;
    document.getElementById('sg-send').disabled = true;

    // User bubble (plain text)
    var ub = addMsg('user'); ub.textContent = q;

    // Typing indicator
    addTyping();

    // Flask API call
    fetch('/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: q })
    })
      .then(parseJsonResponse)
      .then(function (data) {
        removeTyping();
        var bub = addMsg('bot');
        streamHTML(bub, data.html || data.text || '??');
      })
      .catch(function (err) {
        removeTyping();
        var bub = addMsg('bot');
        bub.textContent = '?? Error: ' + err.message;
        isBusy = false;
        document.getElementById('sg-send').disabled = false;
      });
  };

  function sgUploadFile(file) {
    if (!file || isBusy) return;
    isBusy = true;
    document.getElementById('sg-send').disabled = true;
    addTyping();

    var fd = new FormData();
    fd.append('file', file);

    fetch('/chat_upload', { method: 'POST', body: fd })
      .then(parseJsonResponse)
      .then(function (data) {
        removeTyping();
        var bub = addMsg('bot');
        streamHTML(bub, data.html || data.text || 'Upload complete.');
      })
      .catch(function (err) {
        removeTyping();
        var bub = addMsg('bot');
        bub.textContent = 'Upload error: ' + err.message;
        isBusy = false;
        document.getElementById('sg-send').disabled = false;
      });
  }

  window.sgAsk = function (q) {
    document.getElementById('sg-inp').value = q;
    sgSend();
  };

  /* ══════════════════════════════════════════
     VOICE INPUT
  ══════════════════════════════════════════ */
  var recognition = null;
  var isListening = false;
  var pendingTranscript = '';
  var sentFromVoice = false;

  function setVoiceStatus(msg, show) {
    var vs = document.getElementById('sg-voice-status');
    if (!vs) return;
    if (typeof msg === 'string' && msg.length) vs.textContent = msg;
    if (show) vs.classList.add('show');
    else vs.classList.remove('show');
  }

  function sendVoiceTranscript(text) {
    var v = (text || '').trim();
    if (!v) return;
    document.getElementById('sg-inp').value = v;
    setTimeout(function () { sgSend(); }, 250);
  }

  function initVoice() {
    var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return null;
    var r = new SpeechRecognition();
    r.continuous = false;
    r.interimResults = true;
    r.lang = 'ta-IN';

    r.onresult = function (e) {
      var transcript = '';
      for (var i = 0; i < e.results.length; i++) {
        transcript += e.results[i][0].transcript;
      }
      pendingTranscript = transcript;
      document.getElementById('sg-inp').value = transcript;
      if (e.results[e.results.length - 1].isFinal) {
        sentFromVoice = true;
        stopListening();
        sendVoiceTranscript(transcript);
      }
    };

    r.onerror = function (e) {
      var msg = '';
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        msg = 'Microphone blocked. Allow mic for this site and try again.';
      } else if (e.error === 'audio-capture') {
        msg = 'No microphone found. Check your device input.';
      } else if (e.error === 'network') {
        msg = 'Speech service error. Check your internet.';
      } else if (e.error === 'language-not-supported') {
        msg = 'Language not supported. Switching to English.';
        r.lang = 'en-IN';
      } else if (e.error === 'no-speech') {
        msg = 'No speech detected. Try again.';
      } else {
        msg = 'Voice error: ' + e.error;
      }
      setVoiceStatus(msg, true);
      setTimeout(function () { setVoiceStatus(null, false); }, 2500);
      stopListening();
    };

    r.onend = function () {
      if (isListening) stopListening();
      if (!sentFromVoice && pendingTranscript.trim()) {
        sendVoiceTranscript(pendingTranscript);
      }
      pendingTranscript = '';
      sentFromVoice = false;
    };
    return r;
  }

  function startListening() {
    if (!recognition) recognition = initVoice();
    if (!recognition) {
      alert('உங்கள் browser-ல் Voice support இல்ல. Chrome use பண்ணுங்க!');
      return;
    }
    if (!window.isSecureContext && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
      alert('Voice needs HTTPS (or localhost). Please open the site over HTTPS.');
      return;
    }
    recognition.lang = 'ta-IN';
    try { recognition.start(); } catch (e) {
      setVoiceStatus('Voice start failed. Try again.', true);
      setTimeout(function () { setVoiceStatus(null, false); }, 2000);
      return;
    }
    isListening = true;
    document.getElementById('sg-voice').classList.add('listening');
    document.getElementById('sg-voice').textContent = '🔴';
    setVoiceStatus(null, true);
  }

  function stopListening() {
    if (recognition) try { recognition.stop(); } catch (e) { }
    isListening = false;
    document.getElementById('sg-voice').classList.remove('listening');
    document.getElementById('sg-voice').textContent = '🎤';
    setVoiceStatus(null, false);
  }

  window.sgVoice = function () {
    if (isListening) stopListening();
    else startListening();
  };

  /* ══════════════════════════════════════════
     INIT
  ══════════════════════════════════════════ */
  document.addEventListener('DOMContentLoaded', function () {
    var fab = document.getElementById('sg-fab');
    var panel = document.getElementById('sg-panel');
    var handle = document.getElementById('sg-hdr');
    var closeB = document.getElementById('sg-close');
    var inp = document.getElementById('sg-inp');
    var chips = document.querySelector('.sg-chips');

    if (fab) makeDraggable(fab, sgToggle);
    if (panel && handle) makePanelDraggable(panel, handle);

    if (closeB) closeB.addEventListener('click', function (e) {
      e.stopPropagation(); sgToggle();
    });

    if (inp) inp.addEventListener('input', function () {
      this.style.height = 'auto';
      this.style.height = Math.min(this.scrollHeight, 100) + 'px';
    });

  });

})();
