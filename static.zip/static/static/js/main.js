/* Main.js - shared UI behavior */

$(document).ready(function () {
    const $html = $("html");
    const $icon = $("#theme-icon");

    function applyTheme(theme) {
        if (theme === "light") {
            $html.removeClass("dark").addClass("light");
            $icon.removeClass("fa-sun").addClass("fa-moon");
        } else {
            $html.removeClass("light").addClass("dark");
            $icon.removeClass("fa-moon").addClass("fa-sun");
        }
    }

    // Initialize theme from local storage
    const storedTheme = localStorage.getItem("theme") || "dark";
    applyTheme(storedTheme);

    // Theme toggle
    $("#theme-toggle").on("click", function () {
        const nextTheme = $html.hasClass("dark") ? "light" : "dark";
        localStorage.setItem("theme", nextTheme);
        $icon.addClass("animate__animated animate__rotateIn");
        applyTheme(nextTheme);
        setTimeout(() => $icon.removeClass("animate__animated animate__rotateIn"), 500);
    });

    // Small click feedback on interactive elements
    $(document).on("mousedown", "button, a, .clickable", function () {
        const $el = $(this);
        $el.addClass("animate__animated animate__pulse animate__faster");
        setTimeout(() => {
            $el.removeClass("animate__animated animate__pulse animate__faster");
        }, 200);
    });
});
