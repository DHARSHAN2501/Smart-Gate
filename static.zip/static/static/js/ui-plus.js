/* Global UI Plus behaviors: ajax/fetch progress, reveal, ripple, subtle tilt */
(function () {
    if (window.__uiPlusInitialized) return;
    window.__uiPlusInitialized = true;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function ensureProgressBar() {
        let el = document.getElementById("ui-progress");
        if (!el) {
            el = document.createElement("div");
            el.id = "ui-progress";
            document.body.appendChild(el);
        }
        return el;
    }

    let activeRequests = 0;
    const progressEl = () => ensureProgressBar();

    function ensureBackgroundLayers() {
        if (document.getElementById("ui-bg-grid")) return;
        const grid = document.createElement("div");
        grid.id = "ui-bg-grid";
        grid.className = "ui-bg-grid";
        document.body.appendChild(grid);

        const aurora = document.createElement("div");
        aurora.id = "ui-bg-aurora";
        aurora.className = "ui-bg-aurora";
        document.body.appendChild(aurora);
    }

    function ensureDynamicLayers() {
        let canvas = document.getElementById("ui-fx-canvas");
        if (!canvas) {
            canvas = document.createElement("canvas");
            canvas.id = "ui-fx-canvas";
            document.body.appendChild(canvas);
        }

        let fg = document.getElementById("ui-fg-layer");
        if (!fg) {
            fg = document.createElement("div");
            fg.id = "ui-fg-layer";
            fg.innerHTML = [
                "<span class='ui-fg-orb a' data-factor='0.08' aria-hidden='true'></span>",
                "<span class='ui-fg-orb b' data-factor='0.05' aria-hidden='true'></span>",
                "<span class='ui-fg-orb c' data-factor='0.03' aria-hidden='true'></span>",
            ].join("");
            document.body.appendChild(fg);
        }
        return { canvas, fg };
    }

    function initParticleCanvas() {
        if (reduceMotion) return;
        const { canvas } = ensureDynamicLayers();
        const ctx = canvas.getContext("2d", { alpha: true });
        if (!ctx) return;

        let dpr = 1;
        let width = 0;
        let height = 0;
        let particles = [];
        let rafId = 0;
        let frameMinMs = 16;
        let lastTs = 0;
        const pointer = {
            x: window.innerWidth * 0.5,
            y: window.innerHeight * 0.5,
            active: false,
        };

        function getPalette() {
            const dark = document.documentElement.classList.contains("dark");
            if (dark) {
                return {
                    dot: [148, 163, 184],
                    line: [56, 189, 248],
                    lineAlpha: 0.24,
                };
            }
            return {
                dot: [71, 85, 105],
                line: [59, 130, 246],
                lineAlpha: 0.18,
            };
        }

        let palette = getPalette();
        const themeObserver = new MutationObserver(() => {
            palette = getPalette();
        });
        themeObserver.observe(document.documentElement, {
            attributes: true,
            attributeFilter: ["class"],
        });

        function getCount() {
            const area = window.innerWidth * window.innerHeight;
            const coarse = window.matchMedia("(pointer: coarse)").matches;
            const base = Math.round(area / 28000);
            const min = coarse ? 14 : 24;
            const max = coarse ? 24 : 54;
            return Math.max(min, Math.min(max, base));
        }

        function createParticles() {
            const count = getCount();
            particles = Array.from({ length: count }, () => ({
                x: Math.random() * width,
                y: Math.random() * height,
                vx: (Math.random() - 0.5) * 0.5,
                vy: (Math.random() - 0.5) * 0.5,
                r: 0.9 + Math.random() * 1.8,
            }));
        }

        function resize() {
            dpr = Math.min(2, window.devicePixelRatio || 1);
            width = window.innerWidth;
            height = window.innerHeight;
            frameMinMs = window.matchMedia("(pointer: coarse)").matches ? 28 : 16;
            canvas.width = Math.max(1, Math.floor(width * dpr));
            canvas.height = Math.max(1, Math.floor(height * dpr));
            canvas.style.width = `${width}px`;
            canvas.style.height = `${height}px`;
            ctx.setTransform(1, 0, 0, 1, 0, 0);
            ctx.scale(dpr, dpr);
            createParticles();
        }

        function drawFrame(ts = 0) {
            if (ts - lastTs < frameMinMs) {
                rafId = requestAnimationFrame(drawFrame);
                return;
            }
            lastTs = ts;
            ctx.clearRect(0, 0, width, height);

            const maxDist = 128;
            const pointerDist = 130;

            for (let i = 0; i < particles.length; i += 1) {
                const p = particles[i];
                p.x += p.vx;
                p.y += p.vy;

                if (p.x <= 0 || p.x >= width) p.vx *= -1;
                if (p.y <= 0 || p.y >= height) p.vy *= -1;

                if (pointer.active) {
                    const dx = p.x - pointer.x;
                    const dy = p.y - pointer.y;
                    const d2 = dx * dx + dy * dy;
                    if (d2 < pointerDist * pointerDist && d2 > 0.0001) {
                        const d = Math.sqrt(d2);
                        const push = (pointerDist - d) / pointerDist;
                        p.vx += (dx / d) * push * 0.03;
                        p.vy += (dy / d) * push * 0.03;
                    }
                }

                p.vx *= 0.992;
                p.vy *= 0.992;
                p.vx = Math.max(-0.7, Math.min(0.7, p.vx));
                p.vy = Math.max(-0.7, Math.min(0.7, p.vy));

                ctx.beginPath();
                ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(${palette.dot[0]}, ${palette.dot[1]}, ${palette.dot[2]}, 0.55)`;
                ctx.fill();

                for (let j = i + 1; j < particles.length; j += 1) {
                    const q = particles[j];
                    const dx2 = p.x - q.x;
                    const dy2 = p.y - q.y;
                    const dist = Math.hypot(dx2, dy2);
                    if (dist > maxDist) continue;
                    const alpha = (1 - dist / maxDist) * palette.lineAlpha;
                    ctx.strokeStyle = `rgba(${palette.line[0]}, ${palette.line[1]}, ${palette.line[2]}, ${alpha})`;
                    ctx.lineWidth = 1;
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y);
                    ctx.lineTo(q.x, q.y);
                    ctx.stroke();
                }
            }

            rafId = requestAnimationFrame(drawFrame);
        }

        resize();
        drawFrame();

        window.addEventListener("resize", resize);
        window.addEventListener("pointermove", (e) => {
            pointer.x = e.clientX;
            pointer.y = e.clientY;
            pointer.active = true;
        }, { passive: true });
        window.addEventListener("pointerleave", () => {
            pointer.active = false;
        });
        document.addEventListener("visibilitychange", () => {
            if (document.hidden) {
                cancelAnimationFrame(rafId);
                rafId = 0;
                return;
            }
            if (!rafId) {
                drawFrame(performance.now());
            }
        });
    }

    function initForegroundMotion() {
        if (reduceMotion) return;
        const compactDevice = window.matchMedia("(pointer: coarse)").matches || window.matchMedia("(max-width: 480px)").matches;
        if (compactDevice) return;
        const { fg } = ensureDynamicLayers();
        const orbs = Array.from(fg.querySelectorAll(".ui-fg-orb"));
        if (!orbs.length) return;

        const pointer = {
            x: window.innerWidth * 0.5,
            y: window.innerHeight * 0.5,
            tx: window.innerWidth * 0.5,
            ty: window.innerHeight * 0.5,
        };

        const orbState = orbs.map((orb, idx) => ({
            el: orb,
            x: window.innerWidth * (0.35 + idx * 0.17),
            y: window.innerHeight * (0.35 + idx * 0.12),
            factor: Number(orb.dataset.factor || 0.05),
            phase: Math.random() * Math.PI * 2,
            drift: 16 + idx * 10,
        }));

        let rafId = 0;
        function frame(t) {
            pointer.x += (pointer.tx - pointer.x) * 0.08;
            pointer.y += (pointer.ty - pointer.y) * 0.08;

            orbState.forEach((item, idx) => {
                const wobbleX = Math.sin((t * 0.0004) + item.phase) * item.drift;
                const wobbleY = Math.cos((t * 0.00033) + item.phase) * item.drift;
                const targetX = pointer.x + (idx - 1) * 150 + wobbleX;
                const targetY = pointer.y + (idx - 1) * 90 + wobbleY;
                item.x += (targetX - item.x) * item.factor;
                item.y += (targetY - item.y) * item.factor;
                item.el.style.left = `${item.x}px`;
                item.el.style.top = `${item.y}px`;
            });

            rafId = requestAnimationFrame(frame);
        }

        frame(0);

        window.addEventListener("pointermove", (e) => {
            pointer.tx = e.clientX;
            pointer.ty = e.clientY;
        }, { passive: true });

        window.addEventListener("pointerleave", () => {
            pointer.tx = window.innerWidth * 0.5;
            pointer.ty = window.innerHeight * 0.5;
        });

        document.addEventListener("visibilitychange", () => {
            if (document.hidden) {
                cancelAnimationFrame(rafId);
                rafId = 0;
                return;
            }
            if (!rafId) {
                frame(performance.now());
            }
        });
    }

    function initGlobalParallax() {
        if (reduceMotion) return;
        const canParallax = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
        if (!canParallax) return;

        const targets = [
            document.querySelector("nav.glass-panel"),
            document.getElementById("main-container"),
        ].filter(Boolean);
        if (!targets.length) return;
        document.body.classList.add("ui-dynamic");

        const state = { x: 0, y: 0, tx: 0, ty: 0 };
        let rafId = 0;

        function animate() {
            state.x += (state.tx - state.x) * 0.085;
            state.y += (state.ty - state.y) * 0.085;

            targets.forEach((el, idx) => {
                const fx = state.x * (idx === 0 ? 0.7 : 1);
                const fy = state.y * (idx === 0 ? 0.7 : 1);
                el.style.transform = `translate3d(${fx.toFixed(2)}px, ${fy.toFixed(2)}px, 0)`;
            });
            rafId = requestAnimationFrame(animate);
        }

        animate();

        window.addEventListener("pointermove", (e) => {
            const nx = (e.clientX / window.innerWidth) - 0.5;
            const ny = (e.clientY / window.innerHeight) - 0.5;
            state.tx = nx * 5;
            state.ty = ny * 4;
        }, { passive: true });

        window.addEventListener("pointerleave", () => {
            state.tx = 0;
            state.ty = 0;
        });

        document.addEventListener("visibilitychange", () => {
            if (document.hidden) {
                cancelAnimationFrame(rafId);
                rafId = 0;
                return;
            }
            if (!rafId) {
                animate();
            }
        });
    }

    function startProgress() {
        activeRequests += 1;
        const el = progressEl();
        el.style.opacity = "1";
        const target = Math.min(86, 18 + activeRequests * 14);
        el.style.width = `${target}%`;
    }

    function endProgress() {
        activeRequests = Math.max(0, activeRequests - 1);
        const el = progressEl();
        if (activeRequests > 0) {
            const target = Math.min(90, 36 + activeRequests * 10);
            el.style.width = `${target}%`;
            return;
        }
        el.style.width = "100%";
        setTimeout(() => {
            el.style.opacity = "0";
            el.style.width = "0%";
        }, 220);
    }

    // Fetch instrumentation (app-wide AJAX feedback).
    if (typeof window.fetch === "function" && !window.__uiPlusFetchPatched) {
        window.__uiPlusFetchPatched = true;
        const nativeFetch = window.fetch.bind(window);
        window.fetch = function (...args) {
            startProgress();
            return nativeFetch(...args).finally(() => endProgress());
        };
    }

    // jQuery ajax instrumentation.
    if (window.jQuery) {
        const $ = window.jQuery;
        $(document).ajaxSend(() => startProgress());
        $(document).ajaxComplete(() => endProgress());
        $(document).ajaxError(() => endProgress());

        // Ripple for controls.
        $(document).on("click", "button, a[data-ripple], .action-btn", function (e) {
            if (reduceMotion) return;
            const $el = $(this);
            const offset = $el.offset();
            if (!offset) return;

            if ($el.css("position") === "static") {
                $el.css("position", "relative");
            }
            $el.css("overflow", "hidden");

            const x = e.pageX - offset.left;
            const y = e.pageY - offset.top;
            const $ripple = $("<span class='ui-ripple'></span>");
            $ripple.css({ left: `${x}px`, top: `${y}px` });
            $el.append($ripple);
            setTimeout(() => $ripple.remove(), 620);
        });

        // Pulse feedback for high-frequency actions (click/change/submit).
        $(document).on("click change submit", "button, a, input, select, textarea, form", function () {
            if (reduceMotion) return;
            const el = this;
            if (!(el instanceof HTMLElement)) return;
            if (el.classList.contains("ui-action-pulse")) {
                el.classList.remove("ui-action-pulse");
                void el.offsetWidth;
            }
            el.classList.add("ui-action-pulse");
            setTimeout(() => el.classList.remove("ui-action-pulse"), 280);
        });
    }

    function createClickBurst(x, y) {
        if (reduceMotion) return;
        const burst = document.createElement("span");
        burst.className = "ui-click-burst";
        burst.style.left = `${x}px`;
        burst.style.top = `${y}px`;
        document.body.appendChild(burst);
        setTimeout(() => burst.remove(), 620);
    }

    function bindGlobalClickBursts() {
        if (reduceMotion) return;
        document.addEventListener("pointerdown", (e) => {
            if (!e.isPrimary) return;
            createClickBurst(e.clientX, e.clientY);
        }, { passive: true });
    }

    function revealCards() {
        if (reduceMotion) return;
        const cards = Array.from(document.querySelectorAll(".glass-panel"));
        if (!cards.length) return;

        if (!("IntersectionObserver" in window)) {
            cards.forEach((card) => card.classList.add("ui-reveal-in"));
            return;
        }

        const observer = new IntersectionObserver((entries, obs) => {
            entries.forEach((entry) => {
                if (!entry.isIntersecting) return;
                entry.target.classList.add("ui-reveal-in");
                obs.unobserve(entry.target);
            });
        }, { threshold: 0.08 });

        cards.forEach((card) => {
            card.classList.add("ui-reveal-init");
            observer.observe(card);
        });
    }

    function enablePanelTilt() {
        if (reduceMotion) return;
        const canTilt = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
        if (!canTilt) return;
        const panels = document.querySelectorAll(".glass-panel");
        panels.forEach((panel) => {
            if (panel.dataset.uiTiltBound === "1") return;
            panel.dataset.uiTiltBound = "1";

            panel.addEventListener("mousemove", (e) => {
                const rect = panel.getBoundingClientRect();
                const x = (e.clientX - rect.left) / rect.width;
                const y = (e.clientY - rect.top) / rect.height;
                const rx = (0.5 - y) * 2.8;
                const ry = (x - 0.5) * 3.6;
                panel.style.transform = `perspective(1000px) rotateX(${rx.toFixed(2)}deg) rotateY(${ry.toFixed(2)}deg)`;
            });

            panel.addEventListener("mouseleave", () => {
                panel.style.transform = "perspective(1000px) rotateX(0deg) rotateY(0deg)";
            });
        });
    }

    function bindPageTransitions() {
        if (reduceMotion) return;
        document.body.classList.add("ui-page-enter");
        setTimeout(() => document.body.classList.remove("ui-page-enter"), 420);

        document.addEventListener("click", (e) => {
            const target = e.target;
            if (!(target instanceof Element)) return;
            const link = target.closest("a[href]");
            if (!link) return;
            const href = link.getAttribute("href") || "";

            if (!href || href.startsWith("#") || href.startsWith("javascript:")) return;
            if (link.hasAttribute("download") || link.target === "_blank") return;
            if (href.startsWith("/api/")) return;
            if (link.hasAttribute("onclick")) return;

            const url = new URL(link.href, window.location.origin);
            const sameOrigin = url.origin === window.location.origin;
            const current = window.location.pathname + window.location.search;
            const nextPath = url.pathname + url.search;
            if (!sameOrigin || current === nextPath) return;

            e.preventDefault();
            document.body.classList.add("ui-page-leave");
            setTimeout(() => {
                window.location.href = url.href;
            }, 150);
        });
    }

    function initContextualAnimations() {
        document.querySelectorAll(".font-cyber").forEach((el) => {
            el.classList.add("ui-brand-pulse");
        });

        document.querySelectorAll("button, .nav-link, .glass-panel").forEach((el) => {
            el.classList.add("ui-hover-lift");
        });
    }

    function bootUiPlus() {
        ensureBackgroundLayers();
        ensureProgressBar();
        initParticleCanvas();
        initForegroundMotion();
        initGlobalParallax();
        bindGlobalClickBursts();
        bindPageTransitions();
        initContextualAnimations();
        revealCards();
        enablePanelTilt();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", bootUiPlus);
    } else {
        bootUiPlus();
    }
})();
